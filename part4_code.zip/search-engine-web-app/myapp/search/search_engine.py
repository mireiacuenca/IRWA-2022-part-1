import random
from collections import defaultdict
import math
import numpy as np
from myapp.search.objects import ResultItem, Document
from myapp.search.algorithms import build_terms
from myapp.search.algorithms import search_in_corpus

def build_demo_results(corpus: dict, search_id):
    """
    Helper method, just to demo the app
    :return: a list of demo docs sorted by ranking
    """
    res = []
    size = len(corpus)
    ll = list(corpus.values())
    for index in range(random.randint(0, 40)):
        item: Document = ll[random.randint(0, size)]
        res.append(ResultItem(item.id, item.title, item.description, item.doc_date,
                              "doc_details?id={}&search_id={}&param2=2".format(item.id, search_id)))

    # for index, item in enumerate(corpus['Id']):
    #     # DF columns: 'Id' 'Tweet' 'Username' 'Date' 'Hashtags' 'Likes' 'Retweets' 'Url' 'Language'
    #     res.append(DocumentInfo(item.Id, item.Tweet, item.Tweet, item.Date,
    #                             "doc_details?id={}&search_id={}&param2=2".format(item.Id, search_id), random.random()))

    # simulate sort by ranking
    res.sort(key=lambda doc: doc.ranking, reverse=True)
    return res

class SearchEngine:
    """educational search engine"""
    def search(self, search_query, search_id, corpus, index, tf, df, idf, title_index):
        print("Search query:", search_query)

        results = []
        ##### your code here #####
        #results = build_demo_results(corpus, search_id)  # replace with call to search algorithm
        results = search_in_corpus(search_query, corpus, index, tf, df, idf, title_index)
        # results = search_in_corpus(search_query)
        ##### your code here #####

        return results
    
    def create_index(self,lines):
        print(lines)
        index = defaultdict(list)
        title_index = defaultdict(float)
        idf = defaultdict(float)
        tf = defaultdict(list)  #term frequencies of terms in documents
        df = defaultdict(int)  #document frequencies of terms in the corpus
        num_documents = len(lines)
        
        for line in lines:
            terms = build_terms(line.get_description())
            
            page_id = line.get_id()

            
            # The final output must return Tweet, Username, Date, Hashtags, Likes, Retweets and Url
            #args = [line["id"], line['user']['screen_name'], line['created_at'], line['entities']['hashtags'], line['user']['favourites_count'], line['retweet_count'], line['entities']['urls'],line['full_text']]
            
            title_index[page_id]=line
            

            positions_term_in_doc = {}
            for position, term in enumerate(terms):
                try:
                    # if the term is already in the dict append the position to the corresponding list
                    positions_term_in_doc[term].append(position) 
                except:
                    # Add the new term as dict key and initialize the array of positions and add the position
                    positions_term_in_doc[term] = [position]
                    
            norm = 0
            for term, posting in positions_term_in_doc.items():
                norm += len(positions_term_in_doc[term]) ** 2
            norm = math.sqrt(norm)
            
            for term, posting in positions_term_in_doc.items():
                tf[term].append(np.round(len(positions_term_in_doc[term]) / norm, 4))
                df[term] += 1
            
            for term in terms:
                index[term].append(page_id)
                
            for term in df:
                idf[term] = np.round(np.log(float(num_documents / df[term])), 4)
        
        return index, tf, df, idf, title_index
