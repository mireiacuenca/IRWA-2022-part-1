from collections import defaultdict
import math
import numpy as np
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
from numpy import linalg as la
import collections
import string

from myapp.search.objects import ResultItem
from myapp.search.objects import Document

def build_terms(line):

    stemmer = PorterStemmer()
    stop_words = set(stopwords.words("english"))

    #Transform in lowercase
    line=  line.lower()
    
    #Removing punctuation marks
    line= line.translate(str.maketrans('', '', string.punctuation)) 
    
    #Tokenize the text to get a list of terms
    line=  line.split(" ")
    
    #Removing the stopwords
    line=[x for x in line if x not in stop_words]
    
    #Perform stemming
    line=[stemmer.stem(x) for x in line]

    return line

def rank_documents_tf_idf(terms, docs, index, idf, tf, title_index):
    
    doc_vectors = defaultdict(lambda: [0] * len(terms))
    query_vector = [0] * len(terms)

    # compute the norm for the query tf
    query_terms_count = collections.Counter(terms) 

    query_norm = la.norm(list(query_terms_count.values()))

    for termIndex, term in enumerate(terms):
        if term not in index:
            continue

        query_vector[termIndex] = query_terms_count[term] / query_norm * idf[term]
        # Generate doc_vectors for matching docs
        for doc_index, doc in enumerate(index[term]): 
            if doc in docs and len(tf[term])>doc_index:
                doc_vectors[doc][termIndex] = tf[term][doc_index] * idf[term] 

    # Calculate the score of each doc 
    
    doc_scores = [[np.dot(curDocVec, query_vector), doc] for doc, curDocVec in doc_vectors.items()]
    doc_scores.sort(reverse=True)
    print('doc scores: ', doc_scores)
    result_docs = [x[1] for x in doc_scores]
    result_scores= [x[0] for x in doc_scores]
    
    if len(result_docs) == 0:
        print("No results found, try again")
        #query = input()
        #docs = search_tf_idf(query, index)
    return result_scores, result_docs

def search_tf_idf(query, index, idf, tf, title_index):
   
    query = build_terms(query)
    docs = []
    for term in query:
        try:
            #Term is in the index
            keys = [i for i in index.keys()]
            term_docs = [index[t] for t in keys if t==term]
            docs=term_docs[0]
            
        except:
            #Term is not in index
            pass
    docs = list(docs)
    scores_docs,ranked_docs = rank_documents_tf_idf(query, docs, index, idf, tf, title_index)
    return scores_docs,ranked_docs

def search_in_corpus(query, documents, index, tf, df, idf, title_index):

    # 2. apply ranking
    scores_docs, ranked_docs = search_tf_idf(query, index, idf, tf, title_index)
    res = []
    for id in ranked_docs:
        doc = title_index[id]
        res.append(ResultItem(doc.get_id(), doc.get_title(), doc.get_description(), doc.get_doc_date(), doc.get_url()))
    return res
